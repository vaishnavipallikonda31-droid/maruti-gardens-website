import React, { useEffect, useMemo, useState } from "react";
import "./MarutiGardensWebsiteRedesign.css";
const WEBSITE = "https://www.marutigarden.com/";
const PHONE = "+919347525609";
const WHATSAPP = "https://wa.me/919347525609";
const LOGO = "https://www.marutigarden.com/wp-content/uploads/2024/12/cropped-mg-garden-new.png";
const photos = [{
  id: 1,
  category: "Halls",
  label: "Grand celebration hall",
  src: "https://image.wedmegood.com/resized/800X/uploads/member/678116/1716810753_IMG_2098.JPG?crop=32%2C59%2C1320%2C742",
  alt: "Real photograph of Maruti Gardens banquet hall with guest seating and a wedding stage",
  tall: true
}, {
  id: 2,
  category: "Mandapam",
  label: "Floral wedding mandapam",
  src: "https://vmnk.gumlet.io/assets/hyderabad/maruti-garden-lakdikapul/images/original/maruti-garden-lakdikapul-q4iux.jpg",
  alt: "Real photograph of a flower-decorated wedding stage at Maruti Garden",
  tall: false
}, {
  id: 3,
  category: "Entrance",
  label: "A traditional welcome",
  src: "https://image.wedmegood.com/resized/720X/uploads/member/678116/1681280235_5.jpg",
  alt: "Real photograph of the decorated entrance at Maruti Gardens in Lakdikapul",
  tall: false
}, {
  id: 4,
  category: "Halls",
  label: "Aisle to the mandapam",
  src: "https://cdn.venuelook.com/uploads/space_34706/1675171211_595x400.png",
  alt: "Real photograph of Maruti Garden banquet hall with red chairs and a decorated stage",
  tall: true
}, {
  id: 5,
  category: "Mandapam",
  label: "Traditional ceremony setting",
  src: "https://weddingservices.co.in/wsimages/1742966919_maruthi%20t_11zon.jpg",
  alt: "Real photograph of a traditional wedding stage at Maruti Garden",
  tall: false
}, {
  id: 6,
  category: "Entrance",
  label: "Crafted in tradition",
  src: "https://www.bandbaajabarat.com/images/postgallery/1675282677maruti-garden-8.jpg",
  alt: "Real photograph of the carved traditional entrance arch at Maruti Garden",
  tall: false
}];
const services = [{
  number: "01",
  title: "Kalyana Mandapam",
  text: "A traditional setting for the wedding rituals that matter to your family.",
  icon: "mandap",
  href: "https://www.marutigarden.com/pure-veg-kalyana-mandapam-hyderabad/"
}, {
  number: "02",
  title: "Air-conditioned halls",
  text: "Spacious indoor halls for intimate gatherings and celebrations with 900+ guests.",
  icon: "hall",
  href: "https://www.marutigarden.com/pure-veg-ac-banquet-halls-hyderabad/"
}, {
  number: "03",
  title: "Pure vegetarian catering",
  text: "In-house vegetarian catering that brings food and celebration together.",
  icon: "food",
  href: "https://www.marutigarden.com/pure-veg-function-hall-hyderabad/"
}, {
  number: "04",
  title: "Wedding decoration",
  text: "Traditional and contemporary styling, floral arrangements and personalised décor support.",
  icon: "flower",
  href: "https://www.marutigarden.com/wedding-decoration-hyderabad/"
}];
const events = ["Traditional weddings", "Receptions", "Engagements", "Seemantham", "Cradle ceremonies", "Housewarming", "Birthdays", "Corporate events"];
const faqs = [{
  q: "Where is Maruti Gardens located?",
  a: "Maruti Gardens is at 11-4-669/1, opposite Niloufer Road, Red Hills, Lakdikapul, Hyderabad, Telangana 500004."
}, {
  q: "How many guests can the halls accommodate?",
  a: "The website describes the venue as accommodating 900+ guests. Please contact the team to confirm the most suitable hall and seating arrangement for your event."
}, {
  q: "Does the venue offer guest accommodation?",
  a: "Yes. The website lists 30+ luxury air-conditioned rooms for accommodation."
}, {
  q: "Is catering available at the venue?",
  a: "Maruti Gardens offers in-house pure vegetarian catering. Contact the team to discuss your event date and menu requirements."
}, {
  q: "Which occasions can be hosted here?",
  a: "The venue lists weddings, receptions, engagements, cradle ceremonies, Seemantham, birthdays, corporate events and other family celebrations."
}];
function Icon({
  name,
  size = 24
}: {
  name: string;
  size?: number;
}) {
  const common = {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 1.55,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
    "aria-hidden": true as const
  };
  switch (name) {
    case "arrow":
      return <svg {...common}><path d="M4 12h15M13 5l7 7-7 7" /></svg>;
    case "phone":
      return <svg {...common}><path d="M8.2 3.5 5.5 4.8c-.8.4-1.1 1.2-.8 2.1 1.7 5.5 6 9.9 11.6 11.6.9.3 1.7 0 2.1-.8l1.3-2.7-4-2-1.3 1.8a14.6 14.6 0 0 1-4.3-4.3l1.8-1.3-2-4Z" /></svg>;
    case "pin":
      return <svg {...common}><path d="M20 10c0 5-8 11-8 11S4 15 4 10a8 8 0 1 1 16 0Z" /><circle cx="12" cy="10" r="2.5" /></svg>;
    case "calendar":
      return <svg {...common}><rect x="3.5" y="5" width="17" height="15" rx="2" /><path d="M7.5 3v4M16.5 3v4M3.5 9.5h17" /></svg>;
    case "rooms":
      return <svg {...common}><path d="M3 20V5M3 15h18v5M3 12h5a4 4 0 0 1 4 4v4M12 15h6a3 3 0 0 1 3 3" /><path d="M7 8h3" /></svg>;
    case "food":
      return <svg {...common}><path d="M4 13h16a8 8 0 0 1-16 0Z" /><path d="M12 5V3M7.5 7 6 5M16.5 7 18 5" /></svg>;
    case "hall":
      return <svg {...common}><path d="M3 20V9l9-5 9 5v11H3Z" /><path d="M8 20v-6h8v6M7 10h.01M12 10h.01M17 10h.01" /></svg>;
    case "mandap":
      return <svg {...common}><path d="M4 20V7l8-4 8 4v13M2 20h20M7 20v-7h10v7M4 7h16M8 7v6M16 7v6" /><path d="M10 3v4M14 3v4" /></svg>;
    case "flower":
      return <svg {...common}><path d="M12 21v-8M12 9c-3-5 2-8 4-5 2 3-1 5-4 5ZM12 11c-5 2-7-3-4-5 3-1 4 2 4 5ZM12 14c4-3 8 1 5 4-3 2-5-1-5-4ZM12 16c-4 3-8-1-5-4 3-2 5 1 5 4Z" /></svg>;
    case "spark":
      return <svg {...common}><path d="m12 2 1.9 6.1L20 10l-6.1 1.9L12 18l-1.9-6.1L4 10l6.1-1.9L12 2Z" /><path d="m19 16 .9 2.1L22 19l-2.1.9L19 22l-.9-2.1L16 19l2.1-.9L19 16Z" /></svg>;
    case "check":
      return <svg {...common}><path d="m5 12 4 4L19 6" /></svg>;
    case "menu":
      return <svg {...common}><path d="M3 6h18M3 12h18M3 18h18" /></svg>;
    case "close":
      return <svg {...common}><path d="m6 6 12 12M18 6 6 18" /></svg>;
    case "play":
      return <svg {...common}><path d="m9 6 9 6-9 6V6Z" fill="currentColor" stroke="none" /></svg>;
    default:
      return <svg {...common}><circle cx="12" cy="12" r="9" /><path d="M12 8v4l3 2" /></svg>;
  }
}
export const MarutiGardensWebsiteRedesign = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeFilter, setActiveFilter] = useState("All");
  const [selectedPhoto, setSelectedPhoto] = useState<(typeof photos)[number] | null>(null);
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [showBooking, setShowBooking] = useState(false);
  const [form, setForm] = useState({
    name: "",
    phone: "",
    date: "",
    event: "Wedding",
    guests: "300–600 guests"
  });
  const [formError, setFormError] = useState("");
  useEffect(() => {
    const nodes = Array.from(document.querySelectorAll<HTMLElement>(".mg-reveal"));
    if (!("IntersectionObserver" in window)) {
      nodes.forEach(node => node.classList.add("is-visible"));
      return;
    }
    const observer = new IntersectionObserver(entries => entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add("is-visible");
        observer.unobserve(entry.target);
      }
    }), {
      threshold: 0.12
    });
    nodes.forEach(node => observer.observe(node));
    return () => observer.disconnect();
  }, []);
  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setSelectedPhoto(null);
        setShowBooking(false);
        setMenuOpen(false);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);
  const filteredPhotos = useMemo(() => activeFilter === "All" ? photos : photos.filter(photo => photo.category === activeFilter), [activeFilter]);
  const closeMenu = () => setMenuOpen(false);
  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setFormError("");
    if (!form.name.trim() || !form.phone.trim()) {
      setFormError("Please add your name and phone number so the team can respond.");
      return;
    }
    const message = ["Namaste Maruti Gardens, I would like to enquire about an event.", "Name: " + form.name, "Phone: " + form.phone, "Event: " + form.event, "Preferred date: " + (form.date || "Not decided yet"), "Guest count: " + form.guests].join("\n");
    window.open(WHATSAPP + "?text=" + encodeURIComponent(message), "_blank", "noopener,noreferrer");
    setShowBooking(false);
  };
  const scrollToContact = () => {
    setShowBooking(true);
    closeMenu();
  };
  return <div className="mg-site">
      <div className="mg-topline">
        <span className="mg-topline-dot" />
        <span>Timeless celebrations in the heart of Hyderabad</span>
        <a href={"tel:" + PHONE}>Speak to our team <Icon name="arrow" size={13} /></a>
      </div>

      <header className="mg-header">
        <a className="mg-brand" href="#home" aria-label="Maruti Gardens home" onClick={closeMenu}>
          <span className="mg-logo-wrap"><img src={LOGO} alt="Maruti Gardens logo" /></span>
          <span className="mg-brand-copy"><strong>MARUTI GARDENS</strong><small>PURE VEG FUNCTION HALL</small></span>
        </a>
        <button className="mg-menu-toggle" aria-label={menuOpen ? "Close navigation" : "Open navigation"} aria-expanded={menuOpen} onClick={() => setMenuOpen(open => !open)}>
          <Icon name={menuOpen ? "close" : "menu"} size={24} />
        </button>
        <nav className={"mg-nav " + (menuOpen ? "mg-nav-open" : "")} aria-label="Main navigation">
          <a href="#story" onClick={closeMenu}>Our Story</a>
          <a href="#spaces" onClick={closeMenu}>Our Spaces</a>
          <a href="#services" onClick={closeMenu}>Experiences</a>
          <a href="#gallery" onClick={closeMenu}>Gallery</a>
          <a href="#contact" onClick={closeMenu}>Contact</a>
          <button className="mg-nav-cta" onClick={scrollToContact}>Check availability <Icon name="arrow" size={16} /></button>
        </nav>
      </header>

      <main>
        <section className="mg-hero" id="home">
          <div className="mg-hero-ornament mg-ornament-one" aria-hidden="true">✺</div>
          <div className="mg-hero-ornament mg-ornament-two" aria-hidden="true">✧</div>
          <div className="mg-hero-copy">
            <div className="mg-eyebrow"><span /> A LEGACY OF TRADITION · SINCE 1996</div>
            <h1>Where traditions<br />become <em>memories.</em></h1>
            <p className="mg-hero-intro">A thoughtful setting for your most meaningful celebrations — with traditional Kalyana Mandapams, pure vegetarian catering and room for everyone you love.</p>
            <div className="mg-hero-actions">
              <button className="mg-button mg-button-dark" onClick={scrollToContact}>Plan your celebration <Icon name="arrow" size={17} /></button>
              <a className="mg-text-link" href="#gallery"><span className="mg-play"><Icon name="play" size={14} /></span> Explore the venue</a>
            </div>
            <div className="mg-hero-proof">
              <div className="mg-proof-seal"><span>✦</span><strong>Since</strong><b>1996</b></div>
              <div className="mg-proof-text"><strong>Tradition, with thoughtful comfort.</strong><span>Specialising in Brahmin & Arya Vysya weddings</span></div>
            </div>
          </div>
          <div className="mg-hero-visual">
            <div className="mg-hero-image-frame">
              <img className="mg-hero-image" src={photos[0].src} alt={photos[0].alt} fetchPriority="high" />
              <div className="mg-image-glint" aria-hidden="true" />
            </div>
            <div className="mg-image-tag"><span className="mg-tag-icon"><Icon name="spark" size={18} /></span><span><strong>Made for the moment</strong><small>Wedding celebrations at Lakdikapul</small></span></div>
            <div className="mg-vertical-stamp">MARUTI GARDENS <span>✦</span> HYDERABAD</div>
          </div>
          <div className="mg-hero-bottom"><span>PURE VEG · BEAUTIFULLY TRADITIONAL</span><a href="#story">Scroll to discover <span className="mg-scroll-line" /></a></div>
        </section>

        <section className="mg-facts" aria-label="Venue highlights">
          <div className="mg-fact"><span className="mg-fact-icon"><Icon name="calendar" /></span><div><strong>Since 1996</strong><span>A legacy of celebrations</span></div></div>
          <div className="mg-fact"><span className="mg-fact-icon"><Icon name="hall" /></span><div><strong>900+ guests</strong><span>Spacious event capacity</span></div></div>
          <div className="mg-fact"><span className="mg-fact-icon"><Icon name="rooms" /></span><div><strong>30+ AC rooms</strong><span>Comfortable guest stays</span></div></div>
          <div className="mg-fact"><span className="mg-fact-icon"><Icon name="food" /></span><div><strong>Pure vegetarian</strong><span>In-house catering</span></div></div>
        </section>

        <section className="mg-story mg-section" id="story">
          <div className="mg-story-visual mg-reveal">
            <div className="mg-story-photo-main"><img src={photos[2].src} alt={photos[2].alt} loading="lazy" /></div>
            <div className="mg-story-photo-small"><img src={photos[1].src} alt={photos[1].alt} loading="lazy" /></div>
            <div className="mg-round-note"><span>OUR PROMISE</span><strong>Tradition<br />with care</strong><i>✳</i></div>
            <div className="mg-story-border" aria-hidden="true" />
          </div>
          <div className="mg-story-copy mg-reveal">
            <div className="mg-eyebrow"><span /> THE MARUTI GARDENS STORY</div>
            <h2>Rooted in culture.<br /><em>Made for your family.</em></h2>
            <p>Since 1996, Maruti Gardens has welcomed families in Lakdikapul, Hyderabad, for weddings and meaningful gatherings. Our venue brings traditional Kalyana Mandapams together with modern comforts, so your family can focus on the moments that matter.</p>
            <p>With a special understanding of Brahmin and Arya Vysya wedding traditions, we offer a setting shaped around ceremony, hospitality and togetherness.</p>
            <a className="mg-underlined-link" href="https://www.marutigarden.com/about-us/">Discover our story <Icon name="arrow" size={17} /></a>
            <div className="mg-script-note">With tradition, always <span>✦</span></div>
          </div>
        </section>

        <section className="mg-spaces mg-section" id="spaces">
          <div className="mg-section-heading mg-reveal">
            <div><div className="mg-eyebrow"><span /> SPACES FOR EVERY CEREMONY</div><h2>Find your kind<br />of <em>beautiful.</em></h2></div>
            <p>From the sacred wedding ritual to the joyful reception, choose a space that feels right for your people, your rituals and your celebration.</p>
          </div>
          <div className="mg-space-grid">
            <article className="mg-space-card mg-space-large mg-reveal">
              <div className="mg-space-image"><img src={photos[1].src} alt={photos[1].alt} loading="lazy" /><div className="mg-space-index">01 / THE CEREMONY</div></div>
              <div className="mg-space-info"><div><h3>Kalyana Mandapam</h3><p>A traditional centrepiece for your wedding rituals.</p></div><a href="https://www.marutigarden.com/pure-veg-kalyana-mandapam-hyderabad/" aria-label="Explore Kalyana Mandapam"><Icon name="arrow" /></a></div>
            </article>
            <article className="mg-space-card mg-reveal">
              <div className="mg-space-image"><img src={photos[0].src} alt={photos[0].alt} loading="lazy" /><div className="mg-space-index">02 / THE GATHERING</div></div>
              <div className="mg-space-info"><div><h3>AC Function Halls</h3><p>Spacious halls for your larger celebrations.</p></div><a href="https://www.marutigarden.com/pure-veg-ac-banquet-halls-hyderabad/" aria-label="Explore AC function halls"><Icon name="arrow" /></a></div>
            </article>
            <article className="mg-space-card mg-reveal">
              <div className="mg-space-image"><img src={photos[3].src} alt={photos[3].alt} loading="lazy" /><div className="mg-space-index">03 / THE REUNION</div></div>
              <div className="mg-space-info"><div><h3>Receptions & Gatherings</h3><p>Make space for every familiar face.</p></div><a href="https://www.marutigarden.com/pure-veg-function-hall-hyderabad/" aria-label="Explore function hall options"><Icon name="arrow" /></a></div>
            </article>
          </div>
          <div className="mg-space-foot"><span>01 — 03</span><span className="mg-space-foot-line" /><span>Tradition, space and thoughtful hospitality</span></div>
        </section>

        <section className="mg-banner mg-reveal">
          <div className="mg-banner-pattern" aria-hidden="true" />
          <div className="mg-banner-copy"><div className="mg-eyebrow mg-eyebrow-light"><span /> A LITTLE MORE COMFORT</div><h2>Celebrate together.<br /><em>Stay together.</em></h2><p>With 30+ luxury AC rooms, families travelling from outside Hyderabad can stay close to the celebration.</p><button className="mg-button mg-button-light" onClick={scrollToContact}>Enquire about rooms <Icon name="arrow" size={17} /></button></div>
          <div className="mg-banner-image"><img src={photos[2].src} alt="The real decorated entrance at Maruti Gardens" loading="lazy" /><div className="mg-banner-number"><strong>30+</strong><span>Luxury AC<br />rooms</span></div></div>
        </section>

        <section className="mg-services mg-section" id="services">
          <div className="mg-section-heading mg-reveal">
            <div><div className="mg-eyebrow"><span /> THE DETAILS THAT MAKE IT EASIER</div><h2>Everything in one place.<br /><em>Every detail, considered.</em></h2></div>
            <p>The venue, food and finishing touches come together to make planning feel more manageable for your family.</p>
          </div>
          <div className="mg-services-grid">
            {services.map(service => <a className="mg-service-card mg-reveal" key={service.number} href={service.href}>
                <div className="mg-service-top"><span>{service.number}</span><span className="mg-service-icon"><Icon name={service.icon} size={25} /></span></div>
                <h3>{service.title}</h3><p>{service.text}</p><span className="mg-service-link">Explore service <Icon name="arrow" size={15} /></span>
              </a>)}
          </div>
          <div className="mg-perks-row mg-reveal">
            <div><Icon name="check" size={17} /><span>In-house pure vegetarian catering</span></div>
            <div><Icon name="check" size={17} /><span>Decoration assistance</span></div>
            <div><Icon name="check" size={17} /><span>Parking for guests</span></div>
            <div><Icon name="check" size={17} /><span>Event support</span></div>
          </div>
        </section>

        <section className="mg-gallery mg-section" id="gallery">
          <div className="mg-gallery-heading mg-reveal">
            <div><div className="mg-eyebrow"><span /> A LOOK AROUND</div><h2>Real spaces.<br /><em>Real celebrations.</em></h2></div>
            <p>A glimpse of the halls and traditional décor at Maruti Gardens, Lakdikapul.</p>
          </div>
          <div className="mg-gallery-filters" role="group" aria-label="Filter venue photographs">
            {["All", "Halls", "Mandapam", "Entrance"].map(filter => <button key={filter} className={activeFilter === filter ? "active" : ""} onClick={() => setActiveFilter(filter)}>{filter}<span>{filter === "All" ? "06" : String(photos.filter(p => p.category === filter).length).padStart(2, "0")}</span></button>)}
          </div>
          <div className="mg-gallery-grid">
            {filteredPhotos.map((photo, i) => <button className={"mg-gallery-card " + (photo.tall ? "mg-gallery-tall" : "") + " mg-reveal"} key={photo.id} onClick={() => setSelectedPhoto(photo)} aria-label={"View photo: " + photo.label}>
                <img src={photo.src} alt={photo.alt} loading="lazy" />
                <span className="mg-gallery-overlay"><span>{photo.label}</span><span className="mg-gallery-open">↗</span></span>
              </button>)}
          </div>
          <p className="mg-gallery-note">Photographs of Maruti Gardens sourced from its public venue gallery listings.</p>
        </section>

        <section className="mg-occasions mg-section">
          <div className="mg-occasion-intro mg-reveal"><div className="mg-eyebrow"><span /> FOR THE OCCASIONS THAT MATTER</div><h2>Every milestone<br />deserves <em>a place.</em></h2><p>Bring family and friends together for life’s important moments in a setting that honours your traditions.</p><button className="mg-button mg-button-dark" onClick={scrollToContact}>Talk to our team <Icon name="arrow" size={17} /></button></div>
          <div className="mg-occasion-list mg-reveal">
            {events.map((event, index) => <div className="mg-occasion-item" key={event}><span className="mg-occasion-no">{String(index + 1).padStart(2, "0")}</span><span>{event}</span><Icon name="arrow" size={18} /></div>)}
          </div>
        </section>

        <section className="mg-faq mg-section">
          <div className="mg-faq-left mg-reveal"><div className="mg-eyebrow"><span /> A FEW HELPFUL ANSWERS</div><h2>Before you<br /><em>make it yours.</em></h2><p>Have a question about the venue? Here are a few quick details to help you get started.</p><a href="https://www.marutigarden.com/contact-us/" className="mg-underlined-link">More contact details <Icon name="arrow" size={17} /></a></div>
          <div className="mg-faq-list mg-reveal">{faqs.map((faq, index) => <div className={"mg-faq-item " + (openFaq === index ? "open" : "")} key={faq.q}><button onClick={() => setOpenFaq(openFaq === index ? null : index)} aria-expanded={openFaq === index}><span>{faq.q}</span><i>{openFaq === index ? "−" : "+"}</i></button>{openFaq === index && <p>{faq.a}</p>}</div>)}</div>
        </section>

        <section className="mg-contact" id="contact">
          <div className="mg-contact-flower" aria-hidden="true">❋</div>
          <div className="mg-contact-inner mg-reveal">
            <div className="mg-eyebrow mg-eyebrow-light"><span /> YOUR CELEBRATION STARTS HERE</div>
            <h2>Let’s make room<br />for <em>your moments.</em></h2>
            <p>Tell us a little about your event. Our team can help you discuss the date, hall and arrangements.</p>
            <div className="mg-contact-actions"><button className="mg-button mg-button-light" onClick={scrollToContact}>Make an enquiry <Icon name="arrow" size={17} /></button><a href={"tel:" + PHONE} className="mg-contact-phone"><Icon name="phone" size={17} /> +91 93475 25609</a></div>
          </div>
          <div className="mg-contact-details mg-reveal">
            <div><span className="mg-contact-label"><Icon name="pin" size={15} /> VISIT</span><p>11-4-669/1, opposite Niloufer Road,<br />Red Hills, Lakdikapul, Hyderabad<br />Telangana 500004</p><a href="https://maps.google.com/?q=Maruti+Gardens+Lakdikapul+Hyderabad" target="_blank" rel="noreferrer">Get directions <Icon name="arrow" size={14} /></a></div>
            <div><span className="mg-contact-label"><Icon name="phone" size={15} /> CALL</span><p>+91 93475 25609</p><a href={"tel:" + PHONE}>Call the venue <Icon name="arrow" size={14} /></a></div>
            <div><span className="mg-contact-label"><Icon name="calendar" size={15} /> ENQUIRE</span><p>Share your event date<br />and celebration details.</p><button onClick={scrollToContact}>Check availability <Icon name="arrow" size={14} /></button></div>
          </div>
        </section>
      </main>

      <footer className="mg-footer">
        <a className="mg-footer-brand" href="#home"><img src={LOGO} alt="Maruti Gardens logo" /><span><strong>MARUTI GARDENS</strong><small>PURE VEG FUNCTION HALL</small></span></a>
        <p>Tradition since 1996. Celebrations in Lakdikapul, Hyderabad.</p>
        <div className="mg-footer-links"><a href="https://www.marutigarden.com/">Official website</a><a href="https://www.marutigarden.com/about-us/">About</a><a href="https://www.marutigarden.com/blogs/">Blogs</a><a href="mailto:dheeraj.mma@gmail.com">Email</a></div>
        <span className="mg-footer-copy">© Maruti Gardens · Hyderabad</span>
      </footer>

      <a className="mg-whatsapp-float" href={WHATSAPP + "?text=" + encodeURIComponent("Namaste Maruti Gardens, I would like to enquire about an event.")} target="_blank" rel="noreferrer" aria-label="Enquire with Maruti Gardens on WhatsApp">
        <svg viewBox="0 0 24 24" width="21" height="21" fill="currentColor" aria-hidden="true"><path d="M20.4 3.6A11.8 11.8 0 0 0 1.8 17.8L.2 23.7l6-1.6A11.8 11.8 0 0 0 20.4 3.6ZM12 21a9.7 9.7 0 0 1-4.9-1.3l-.4-.2-3.6 1 1-3.5-.2-.4A9.8 9.8 0 1 1 12 21Zm5.4-7.3c-.3-.2-1.8-.9-2.1-1s-.5-.2-.7.2-.8 1-1 1.2-.4.2-.7.1a8 8 0 0 1-2.4-1.5 9 9 0 0 1-1.7-2.1c-.2-.3 0-.5.1-.6l.5-.6.3-.5c.1-.2 0-.4 0-.6l-.9-2.2c-.2-.6-.5-.5-.7-.5h-.6c-.2 0-.6.1-.9.4-.3.4-1.1 1.1-1.1 2.7s1.1 3.1 1.3 3.4a12 12 0 0 0 4.5 4c.6.2 1.1.4 1.5.5.6.2 1.2.1 1.7.1.5-.1 1.8-.7 2-1.4.3-.7.3-1.3.2-1.4-.1-.1-.3-.2-.6-.4Z" /></svg>
      </a>

      {showBooking && <div className="mg-modal-backdrop" role="presentation" onMouseDown={event => {
      if (event.target === event.currentTarget) setShowBooking(false);
    }}>
        <div className="mg-booking-modal" role="dialog" aria-modal="true" aria-labelledby="mg-booking-title">
          <button className="mg-modal-close" onClick={() => setShowBooking(false)} aria-label="Close enquiry form"><Icon name="close" size={22} /></button>
          <div className="mg-eyebrow"><span /> EVENT ENQUIRY</div>
          <h2 id="mg-booking-title">Tell us about<br /><em>your celebration.</em></h2>
          <p className="mg-form-intro">Share the basics and continue to WhatsApp to discuss availability with the venue team.</p>
          <form onSubmit={handleSubmit}>
            <label>Your name<input value={form.name} onChange={e => setForm({
              ...form,
              name: e.target.value
            })} placeholder="Enter your name" autoComplete="name" /></label>
            <label>Phone number<input value={form.phone} onChange={e => setForm({
              ...form,
              phone: e.target.value
            })} placeholder="Your contact number" inputMode="tel" autoComplete="tel" /></label>
            <div className="mg-form-row"><label>Event type<select value={form.event} onChange={e => setForm({
                ...form,
                event: e.target.value
              })}>{["Wedding", "Reception", "Engagement", "Seemantham", "Cradle ceremony", "Birthday", "Corporate event", "Other family function"].map(item => <option key={item}>{item}</option>)}</select></label><label>Guests<select value={form.guests} onChange={e => setForm({
                ...form,
                guests: e.target.value
              })}>{["Below 100", "100–300 guests", "300–600 guests", "600–900 guests", "900+ guests", "Not decided"].map(item => <option key={item}>{item}</option>)}</select></label></div>
            <label>Preferred date<input type="date" value={form.date} onChange={e => setForm({
              ...form,
              date: e.target.value
            })} /></label>
            {formError && <p className="mg-form-error" role="alert">{formError}</p>}
            <button className="mg-button mg-button-dark mg-form-submit" type="submit">Continue on WhatsApp <Icon name="arrow" size={17} /></button>
            <p className="mg-form-privacy">Your details will be used to prepare the enquiry message on WhatsApp.</p>
          </form>
        </div>
      </div>}

      {selectedPhoto && <div className="mg-lightbox" role="presentation" onMouseDown={event => {
      if (event.target === event.currentTarget) setSelectedPhoto(null);
    }}>
        <button className="mg-lightbox-close" aria-label="Close image" onClick={() => setSelectedPhoto(null)}><Icon name="close" size={24} /></button>
        <img src={selectedPhoto.src} alt={selectedPhoto.alt} />
        <div className="mg-lightbox-caption">{selectedPhoto.label}<span>{selectedPhoto.category}</span></div>
      </div>}
    </div>;
};