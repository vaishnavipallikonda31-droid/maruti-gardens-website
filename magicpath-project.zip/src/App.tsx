import { Theme } from './settings/types';
import { MarutiGardensWebsiteRedesign } from './components/generated/MarutiGardensWebsiteRedesign';

let theme: Theme = 'light';

function App() {
  function setTheme(theme: Theme) {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }

  setTheme(theme);

  return (
    <>
      <MarutiGardensWebsiteRedesign />
    </>
  ); // %EXPORT_STATEMENT%
}

export default App;
